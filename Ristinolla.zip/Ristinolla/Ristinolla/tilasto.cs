﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;




using static Ristinolla.Ristinolla;
using static System.Windows.Forms.LinkLabel;

namespace Ristinolla
{
    public partial class tilasto : Form
    {
        public tilasto()
        {
            InitializeComponent();



        }

        private void tilasto_Load(object sender, EventArgs e)
        {

        }

        private void tilastolabel_Click(object sender, EventArgs e)
        {

        }

        void t_tick(object sender, EventArgs e)
        {
            update.Enabled = true;
            t.Stop();
        }


        Timer t = new Timer();

        private void update_Click(object sender, EventArgs e)
        {

            //Päivitetään tulokset lista
            //Lukee Tilastot.txt ja listaa tiedot listboxiin

            string[] lines = File.ReadAllLines(@"c:\Ristinolla\Tulokset.txt");

            foreach (string line in lines)
            {
                // Use a tab to indent each line of the file.
                tilastolist.Items.Add(line + "\t" );

            }


            //Estää napin spämmin ajastimen avulla

            t.Interval = 5000; 
            t.Tick += t_tick;
            t.Start();
            update.Enabled = false;
        }

        


        private void tilastolist_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}