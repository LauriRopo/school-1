﻿namespace Ristinolla
{
    partial class tilasto
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tilastolabel = new System.Windows.Forms.Label();
            this.tilastolist = new System.Windows.Forms.ListBox();
            this.update = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // tilastolabel
            // 
            this.tilastolabel.AutoSize = true;
            this.tilastolabel.Font = new System.Drawing.Font("Arial Rounded MT Bold", 21.75F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tilastolabel.Location = new System.Drawing.Point(70, 9);
            this.tilastolabel.Name = "tilastolabel";
            this.tilastolabel.Size = new System.Drawing.Size(110, 33);
            this.tilastolabel.TabIndex = 0;
            this.tilastolabel.Text = "Tilasto";
            this.tilastolabel.Click += new System.EventHandler(this.tilastolabel_Click);
            // 
            // tilastolist
            // 
            this.tilastolist.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tilastolist.FormattingEnabled = true;
            this.tilastolist.Location = new System.Drawing.Point(12, 126);
            this.tilastolist.Name = "tilastolist";
            this.tilastolist.Size = new System.Drawing.Size(215, 173);
            this.tilastolist.TabIndex = 1;
            this.tilastolist.SelectedIndexChanged += new System.EventHandler(this.tilastolist_SelectedIndexChanged);
            // 
            // update
            // 
            this.update.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.update.Font = new System.Drawing.Font("Arial Rounded MT Bold", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.update.Location = new System.Drawing.Point(12, 77);
            this.update.Name = "update";
            this.update.Size = new System.Drawing.Size(90, 33);
            this.update.TabIndex = 2;
            this.update.Text = "Päivitä";
            this.update.UseVisualStyleBackColor = true;
            this.update.Click += new System.EventHandler(this.update_Click);
            // 
            // tilasto
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Maroon;
            this.ClientSize = new System.Drawing.Size(252, 360);
            this.Controls.Add(this.update);
            this.Controls.Add(this.tilastolist);
            this.Controls.Add(this.tilastolabel);
            this.Name = "tilasto";
            this.Text = "tilasto";
            this.Load += new System.EventHandler(this.tilasto_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label tilastolabel;
        private System.Windows.Forms.ListBox tilastolist;
        private System.Windows.Forms.Button update;
    }
}