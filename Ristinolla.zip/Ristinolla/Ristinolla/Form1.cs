﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Text;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using static Ristinolla.ilmoitus;
using static Ristinolla.tassapeli;
using static Ristinolla.tilasto;

namespace Ristinolla
{
    public partial class Ristinolla : Form
    {
        bool KenenVuoroMääritelmä = true;
        bool voittaja = true;




        public struct pelaajatiedot
        {
            public string nimi;
            


        }

        public Ristinolla()
        {
            InitializeComponent();

        }

        private void Form1_Load(object sender, EventArgs e)
        {


        }
        private void nimitiedot_Enter(object sender, EventArgs e)
        {

        }
        private void button3_Click(object sender, EventArgs e)
        {
            //Aloittaa pelin

            nimitiedot.Visible = false;
            peli.Visible = true;
        }
        private void button10_MouseClick(object sender, MouseEventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {
            //Kun painetaan nappia jos vuoro on "True" ilmestyy X ja jos vuoro ei ole "true" ilmestyy O. 
            // Nappi menee samalla kiini, sitä ei voi enää painaa

            button6.Enabled = false;

            Button n = (Button)sender;
            if (KenenVuoroMääritelmä)
            {
                n.Text = "X";
            }
            else
            {
                n.Text = "O";
            }
            KenenVuoroMääritelmä = !KenenVuoroMääritelmä;

            if (KenenVuoroMääritelmä == true)
            {
                vuorox.Visible = true;
                vuoroo.Visible = false;
            }
            else
            {
                vuorox.Visible = false;
                vuoroo.Visible = true;
            }
            Voittaja();
            tietokone();
            tasapeli();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            button1.Enabled = false;

            Button n = (Button)sender;
            if (KenenVuoroMääritelmä)
            {
                n.Text = "X";

            }
            else
            {
                n.Text = "O";

            }
            KenenVuoroMääritelmä = !KenenVuoroMääritelmä;

            //Tämä kertoo onko X vai O vuoro. Sama koodin pätkä löytyy joka napista

            if (KenenVuoroMääritelmä == true)
            {
                vuorox.Visible = true;
                vuoroo.Visible = false;
            }
            else
            {
                vuorox.Visible = false;
                vuoroo.Visible = true;
            }
            Voittaja();
            tietokone();
            tasapeli();


        }

        private void button4_Click(object sender, EventArgs e)
        {
            button4.Enabled = false;

            Button n = (Button)sender;
            if (KenenVuoroMääritelmä)
            {
                n.Text = "X";

            }
            else
            {
                n.Text = "O";

            }
            KenenVuoroMääritelmä = !KenenVuoroMääritelmä;

            if (KenenVuoroMääritelmä == true)
            {
                vuorox.Visible = true;
                vuoroo.Visible = false;
            }
            else
            {
                vuorox.Visible = false;
                vuoroo.Visible = true;
            }
            Voittaja();
            tietokone();
            tasapeli();

        }

        private void button7_Click(object sender, EventArgs e)
        {
            button7.Enabled = false;

            Button n = (Button)sender;
            if (KenenVuoroMääritelmä)
            {
                n.Text = "X";
            }
            else
            {
                n.Text = "O";
            }
            KenenVuoroMääritelmä = !KenenVuoroMääritelmä;

            if (KenenVuoroMääritelmä == true)
            {
                vuorox.Visible = true;
                vuoroo.Visible = false;
            }
            else
            {
                vuorox.Visible = false;
                vuoroo.Visible = true;
            }
            Voittaja();
            tietokone();
            tasapeli();

        }

        private void button5_Click(object sender, EventArgs e)
        {
            button5.Enabled = false;

            Button n = (Button)sender;
            if (KenenVuoroMääritelmä)
            {
                n.Text = "X";
            }
            else
            {
                n.Text = "O";
            }
            KenenVuoroMääritelmä = !KenenVuoroMääritelmä;

            if (KenenVuoroMääritelmä == true)
            {
                vuorox.Visible = true;
                vuoroo.Visible = false;
            }
            else
            {
                vuorox.Visible = false;
                vuoroo.Visible = true;
            }

            Voittaja();
            tietokone();
            tasapeli();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            button8.Enabled = false;

            Button n = (Button)sender;
            if (KenenVuoroMääritelmä)
            {
                n.Text = "X";
            }
            else
            {
                n.Text = "O";
            }
            KenenVuoroMääritelmä = !KenenVuoroMääritelmä;

            if (KenenVuoroMääritelmä == true)
            {
                vuorox.Visible = true;
                vuoroo.Visible = false;
            }
            else
            {
                vuorox.Visible = false;
                vuoroo.Visible = true;
            }
            Voittaja();
            tietokone();
            tasapeli();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            button9.Enabled = false;

            Button n = (Button)sender;
            if (KenenVuoroMääritelmä)
            {
                n.Text = "X";

            }
            else
            {
                n.Text = "O";
            }
            KenenVuoroMääritelmä = !KenenVuoroMääritelmä;

            if (KenenVuoroMääritelmä == true)
            {
                vuorox.Visible = true;
                vuoroo.Visible = false;
            }
            else
            {
                vuorox.Visible = false;
                vuoroo.Visible = true;
            }
            Voittaja();
            tietokone();
            tasapeli();

        }

        private void button10_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            button3.Enabled = false;

            Button n = (Button)sender;
            if (KenenVuoroMääritelmä)
            {
                n.Text = "X";
            }
            else
            {
                n.Text = "O";
            }
            KenenVuoroMääritelmä = !KenenVuoroMääritelmä;

            if (KenenVuoroMääritelmä == true)
            {
                vuorox.Visible = true;
                vuoroo.Visible = false;
            }
            else
            {
                vuorox.Visible = false;
                vuoroo.Visible = true;
            }
            Voittaja();
            tietokone();
            tasapeli();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            button2.Enabled = false;

            Button n = (Button)sender;
            if (KenenVuoroMääritelmä)
            {
                n.Text = "X";

            }
            else
            {
                n.Text = "O";

            }
            KenenVuoroMääritelmä = !KenenVuoroMääritelmä;

            if (KenenVuoroMääritelmä == true)
            {
                vuorox.Visible = true;
                vuoroo.Visible = false;
            }
            else
            {
                vuorox.Visible = false;
                vuoroo.Visible = true;
            }
            Voittaja();
            tietokone();
            tasapeli();
        }
        private void tietokone()
        {

            //Tietokonetta varten koodi. Tarkistaa jos jokin nappi painetaan ja painaa sen mukaan sitten jotain kolmesta mahdollisesta 
            // vaihtoehdosta



            if (KenenVuoroMääritelmä == false && VSkone.Checked)
            {



                for (int i = 0; i < 1; i++)
                {
                    if (button1.Enabled == false)
                    {
                        if (button2.Enabled == true)
                        {

                            button2.PerformClick();
                            button2.Enabled = false;
                            break;

                        }
                        else if (button3.Enabled == true)
                        {
                            button3.PerformClick();
                            button3.Enabled = false;
                            break;
                        }
                        else
                        {
                            button4.PerformClick();
                            button4.Enabled = false;
                            break;
                        }

                    }
                    if (button2.Enabled == false)
                    {
                        if (button1.Enabled == true)
                        {
                            button1.PerformClick();
                            button1.Enabled = false;
                            break;
                        }
                        else if (button9.Enabled == true)
                        {
                            button9.PerformClick();
                            button9.Enabled = false;
                            break;
                        }
                        else
                        {
                            button4.PerformClick();
                            button4.Enabled = false;
                            break;
                        }
                    }
                    if (button3.Enabled == false)
                    {
                        if (button4.Enabled == true)
                        {
                            button4.PerformClick();
                            button4.Enabled = false;
                            break;
                        }
                        else if (button7.Enabled == true)
                        {
                            button7.PerformClick();
                            button7.Enabled = false;
                            break;
                        }
                        else
                        {
                            button5.PerformClick();
                            button5.Enabled = false;
                            break;
                        }
                    }
                    if (button4.Enabled == false)
                    {
                        if (button3.Enabled == true)
                        {
                            button3.PerformClick();
                            button3.Enabled = false;
                            break;
                        }
                        else if (button2.Enabled == true)
                        {
                            button2.PerformClick();
                            button2.Enabled = false;
                            break;
                        }
                        else
                        {
                            button5.PerformClick();
                            button5.Enabled = false;
                            break;

                        }
                    }
                    if (button5.Enabled == false)
                    {
                        if (button3.Enabled == true)
                        {
                            button3.PerformClick();
                            button3.Enabled = false;
                            break;

                        }
                        else if (button8.Enabled == true)
                        {
                            button8.PerformClick();
                            button8.Enabled = false;
                            break;
                        }

                        else
                        {
                            button6.PerformClick();
                            button6.Enabled = false;
                            break;
                        }
                    }
                    if (button6.Enabled == false)
                    {
                        if (button5.Enabled == true)
                        {
                            button5.PerformClick();
                            button5.Enabled = false;
                            break;
                        }
                        else if (button1.Enabled == true)
                        {
                            button1.PerformClick();
                            button1.Enabled = false;
                            break;
                        }
                        else
                        {
                            button7.PerformClick();
                            button7.Enabled = false;
                            break;
                        }
                    }
                    if (button7.Enabled == false)
                    {
                        if (button6.Enabled == true)
                        {
                            button6.PerformClick();
                            button6.Enabled = false;
                            break;
                        }
                        else if (button9.Enabled == true)
                        {
                            button9.PerformClick();
                            button9.Enabled = false;
                            break;
                        }
                        else
                        {
                            button8.PerformClick();
                            button8.Enabled = false;
                            break;
                        }
                    }
                    if (button8.Enabled == false)
                    {
                        if (button7.Enabled == true)
                        {
                            button7.PerformClick();
                            button7.Enabled = false;
                            break;
                        }
                        else if (button5.Enabled == true)
                        {
                            button5.PerformClick();
                            button5.Enabled = false;
                            break;
                        }
                        else if (button1.Enabled == true)
                        {
                            button1.PerformClick();
                            button1.Enabled = false;
                            break;
                        }

                        else
                        {
                            button9.PerformClick();
                            button9.Enabled = false;
                            break;
                        }
                    }
                    if (button9.Enabled == false)
                    {
                        if (button1.Enabled == true)
                        {
                            button1.PerformClick();
                            button1.Enabled = false;
                            break;

                        }
                        else if (button2.Enabled == true)
                        {
                            button2.PerformClick();
                            button2.Enabled = false;
                            break;

                        }
                        else
                        {
                            button8.PerformClick();
                            button8.Enabled = false;
                            break;
                        }
                    }
                }


            }

        }



       

        private void Pelaaja1bt_Click(object sender, EventArgs e)
        {
            // Tallennetaan pelaaja 1 tiedot

            //Jos tietoja ei syötä tulee Error viesti



            if (nimitxt.Text == "")
            {

                string Error = "Syötä tiedot";
                MessageBox.Show(Error);

            }
            else
            {
                VSkone.Visible = true;

                if (VSkone.Checked == true)
                {
                    Aloitanappi.Visible = true;
                }

                Pelaaja2bt.Visible = true;
                Pelaaja1bt.Visible = false;
            }

            string fileName = @"c:\Ristinolla\Pelaaja1.txt";
            string directory = Path.GetDirectoryName(fileName);
            if (!Directory.Exists(directory))
            {
                Directory.CreateDirectory(directory);
            }
            FileStream FS = new FileStream(fileName, FileMode.Append);

            StreamWriter sw = new StreamWriter(FS);

            pelaajatiedot p;
            p.nimi = nimitxt.Text;
            


            sw.WriteLine(p.nimi);
            sw.WriteLine(syntymäaika);
            //sw.WriteLine(p.syntymäaika);

            sw.Close();
            FS.Close();

            nimitxt.Clear();
            

        }

        private void Pelaaja2bt_Click(object sender, EventArgs e)
        {

            Aloitanappi.Visible = true;
            VSkone.Visible = false;

            //Tallentaa pelaaja 2 tiedot
            // jos tietoja ei anna tulee Error viesti
            // Jos tietoja ei syötä aloitus nappi häviää, mutta jos päättää pelata konetta vastaan se tulee takaisin näkyviin

            if (nimitxt.Text == "")
            {

                string Error = "Syötä tiedot";
                MessageBox.Show(Error);

                Aloitanappi.Visible = false;

            }
            else
            {
                VSkone.Visible = true;

                if (VSkone.Visible == true)
                {
                    Aloitanappi.Visible = true;
                }

                Pelaaja2bt.Visible = true;
                Pelaaja1bt.Visible = false;
            }

            string fileName = @"c:\Ristinolla\Pelaaja2.txt";
            string directory = Path.GetDirectoryName(fileName);
            if (!Directory.Exists(directory))
            {
                Directory.CreateDirectory(directory);
            }
            FileStream FS = new FileStream(fileName, FileMode.Append);

            StreamWriter sw = new StreamWriter(FS);

            pelaajatiedot p;
            p.nimi = nimitxt.Text;
            


            sw.WriteLine(p.nimi);
            sw.WriteLine(syntymäaika);

            sw.Close();
            FS.Close();

            nimitxt.Clear();
            
        }

        private void peli_Enter(object sender, EventArgs e)
        {

            




        }
        private void Voittaja()
        {





            //Määrittelee onko joku pelaajista saannut kolmen suoran

            // Määrittelee voittajan vaakariveillä

            if ((button1.Text == button2.Text) && (button2.Text == button4.Text) && (button1.Enabled == false))
            {


                if (VSkone.Checked)
                {
                    KonetettaVastaanLopputulos();
                }

                voittaja = true;

                tulostallennus();
                VoittajaViesti();



            }
            else if ((button7.Text == button6.Text) && (button6.Text == button5.Text) && (button7.Enabled == false))
            {


                if (VSkone.Checked)
                {
                    KonetettaVastaanLopputulos();
                }

                voittaja = true;

                tulostallennus();
                VoittajaViesti();


            }
            else if ((button8.Text == button9.Text) && (button9.Text == button3.Text) && (button8.Enabled == false))
            {
                if (VSkone.Checked)
                {
                    KonetettaVastaanLopputulos();
                }


                voittaja = true;

                tulostallennus();
                VoittajaViesti();


            }

            //Määrittelee voittajan pystyriveillä

            if ((button1.Text == button7.Text) && (button7.Text == button8.Text) && (button1.Enabled == false))
            {

                if (VSkone.Checked)
                {
                    KonetettaVastaanLopputulos();
                }

                voittaja = true;

                tulostallennus();
                VoittajaViesti();



            }
            else if ((button2.Text == button6.Text) && (button6.Text == button9.Text) && (button2.Enabled == false))
            {

                if (VSkone.Checked)
                {
                    KonetettaVastaanLopputulos();
                }

                voittaja = true;

                tulostallennus();
                VoittajaViesti();


            }
            else if ((button4.Text == button5.Text) && (button5.Text == button3.Text) && (button4.Enabled == false))
            {


                if (VSkone.Checked)
                {
                    KonetettaVastaanLopputulos();
                }

                voittaja = true;

                tulostallennus();
                VoittajaViesti();


            }


            //Määrittelee voittajan vinoriveillä

            if ((button1.Text == button6.Text) && (button6.Text == button3.Text) && (button1.Enabled == false))
            {

                if (VSkone.Checked)
                {
                    KonetettaVastaanLopputulos();
                }

                voittaja = true;

                tulostallennus();
                VoittajaViesti();

            }
            else if ((button4.Text == button6.Text) && (button6.Text == button8.Text) && (button4.Enabled == false))
            {

                if (VSkone.Checked)
                {
                    KonetettaVastaanLopputulos();
                }


                voittaja = true;

                tulostallennus();
                VoittajaViesti();


            }
        }
        private void VoittajaViesti()
        {
            // Ilmoittaa kuka voitti pelin kun pelataan VS pelaaja

            string Xvoitti = "Pelaaja 1 'X' voitti!";
            string Ovoitti = "Pelaaja 2 'O' voitti!";



            if (voittaja == true && VSkone.Checked == false)
            {

                if (voittaja == true && KenenVuoroMääritelmä == false)
                {
                    MessageBox.Show(Xvoitti);

                    ilmoitus f2 = new ilmoitus();
                    f2.ShowDialog();
                }
                else if (VSkone.Checked == false && voittaja == true && KenenVuoroMääritelmä == true)
                {
                    MessageBox.Show(Ovoitti);

                    ilmoitus f2 = new ilmoitus();
                    f2.ShowDialog();
                }

            }

        }

        private void KonetettaVastaanLopputulos()
        {

            // ilmoittaa lopputuloksen VS kone

            string tasapelivskone = "Tasapeli VS kone!";
            string konevoitti = "Kone voitt!i";
            string Pelaaja = "Pelaaja voitti!";

            if ((button1.Enabled == false && button2.Enabled == false && button3.Enabled == false && button4.Enabled == false && button5.Enabled == false && button6.Enabled == false && button7.Enabled == false && button8.Enabled == false && button9.Enabled == false && KenenVuoroMääritelmä == true))
            {
                MessageBox.Show(tasapelivskone);

            }
            else if (KenenVuoroMääritelmä != false)
            {
                MessageBox.Show(konevoitti);
            }
            else if (KenenVuoroMääritelmä != true)
            {
                MessageBox.Show(Pelaaja);
                KenenVuoroMääritelmä = true;
            }

        }

        private void tasapeli()
        {
            // jos kaikki napit on painettu, peli päättyy tasapeliin
            // tasapeli ikkuna tuulee ruudelle

            if (button1.Enabled == false && button2.Enabled == false && button3.Enabled == false && button4.Enabled == false && button5.Enabled == false && button6.Enabled == false && button7.Enabled == false && button8.Enabled == false && button9.Enabled == false)
            {

                // jos kaikki napit on painettu, peli päättyy tasapeliin
                // Tuloksiin tallentuu tasapeli

                if (VSkone.Checked == false && voittaja == true)
                {
                    tassapeli f3 = new tassapeli();
                    f3.ShowDialog();
                }

                string fileName = @"c:\Ristinolla\Tulokset.txt";
                string directory = Path.GetDirectoryName(fileName);
                if (!Directory.Exists(directory))
                {
                    Directory.CreateDirectory(directory);
                }
                FileStream FS = new FileStream(fileName, FileMode.Append);

                StreamWriter sw = new StreamWriter(FS);

                if (VSkone.Checked)
                {
                    sw.WriteLine("Tasapeli konetta vastaan\t");


                }
                else
                {
                    sw.WriteLine("Tasapeli pelaajaa vastaan\t");

                }

                sw.Close();
                FS.Close();
            }
        }

        private void tulostallennus()
        {
            // Tallennetaan pelin lopputulos kansioon
            // jos "KenenVuoroMääritelmä" on "true" oli X pelaajan vuoro ja jos on "false" on O pelaajan vuoro




            if (KenenVuoroMääritelmä == false)
            {



                string fileName = @"c:\Ristinolla\Tulokset.txt";
                string directory = Path.GetDirectoryName(fileName);
                if (!Directory.Exists(directory))
                {
                    Directory.CreateDirectory(directory);
                }
                FileStream FS = new FileStream(fileName, FileMode.Append);

                StreamWriter sw = new StreamWriter(FS);




                sw.WriteLine("Pelaaja 1 eli X voitti\t");



                sw.Close();
                FS.Close();


            }
            else if (KenenVuoroMääritelmä == true)
            {
                string fileName = @"c:\Ristinolla\Tulokset.txt";
                string directory = Path.GetDirectoryName(fileName);
                if (!Directory.Exists(directory))
                {
                    Directory.CreateDirectory(directory);
                }
                FileStream FS = new FileStream(fileName, FileMode.Append);

                StreamWriter sw = new StreamWriter(FS);



                if (VSkone.Checked)
                {
                    sw.WriteLine("Kone voitti\t");
                }
                else
                {
                    sw.WriteLine("Pelaaja 2 eli O voitti\t");
                }


                sw.Close();
                FS.Close();


            }
        }

        private void vuorox_Click(object sender, EventArgs e)
        {

        }

        private void vuoroo_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void VSkone_CheckedChanged(object sender, EventArgs e)
        {
            //kun laitetaan rasti VS kone niin alotis nappi tulee näkyviin

            if (VSkone.Checked)
            {
                Aloitanappi.Visible = true;
            }
        }

        private void nimitxt_TextChanged(object sender, EventArgs e)
        {

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void Tilasto_Click(object sender, EventArgs e)
        {
            //Tilasto form tulee näkyviin

            tilasto f4 = new tilasto();
            f4.ShowDialog();
        }

        private void uudestaan_Click(object sender, EventArgs e)
        {

            // Aloittaa pelin alusta. Tyhjentää napeista tekstit ja enabloi ne uudestaa jotta niitä voi painaa
            // Vuoro myös siirtyy takaisin Pelaaja 1 eli X



            if (KenenVuoroMääritelmä == false)
            {
                KenenVuoroMääritelmä = true;
                vuoroo.Visible = false;
                vuorox.Visible = true;

            }



            button1.Text = string.Empty;
            button2.Text = string.Empty;
            button3.Text = string.Empty;
            button4.Text = string.Empty;
            button5.Text = string.Empty;
            button6.Text = string.Empty;
            button7.Text = string.Empty;
            button8.Text = string.Empty;
            button9.Text = string.Empty;

            button1.Enabled = true;
            button2.Enabled = true;
            button3.Enabled = true;
            button4.Enabled = true;
            button5.Enabled = true;
            button6.Enabled = true;
            button7.Enabled = true;
            button8.Enabled = true;
            button9.Enabled = true;
        }

        private void takaisin_Click(object sender, EventArgs e)
        {
            // Piilottaa pelin ja aukaisee kirjautumis menun takaisin

            peli.Visible = false;
            Pelaaja1bt.Visible = true;
            Pelaaja2bt.Visible = false;
            VSkone.Visible = false;
            Aloitanappi.Visible = false;

            nimitiedot.Visible = true;
        }

        private void syntymäaika_ValueChanged(object sender, EventArgs e)
        {
            syntymäaika.MinDate = new DateTime(1800, 1, 1);
            syntymäaika.MaxDate = DateTime.Today;

            
        }
    }
}