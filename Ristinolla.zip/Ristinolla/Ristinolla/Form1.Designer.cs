﻿namespace Ristinolla
{
    partial class Ristinolla
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.nimi = new System.Windows.Forms.Label();
            this.saika = new System.Windows.Forms.Label();
            this.nimitiedot = new System.Windows.Forms.GroupBox();
            this.VSkone = new System.Windows.Forms.CheckBox();
            this.Pelaaja2bt = new System.Windows.Forms.Button();
            this.Pelaaja1bt = new System.Windows.Forms.Button();
            this.Aloitanappi = new System.Windows.Forms.Button();
            this.nimitxt = new System.Windows.Forms.TextBox();
            this.peli = new System.Windows.Forms.GroupBox();
            this.uudestaan = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.vuoroo = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.vuorox = new System.Windows.Forms.Label();
            this.button3 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.Tilasto = new System.Windows.Forms.Button();
            this.takaisin = new System.Windows.Forms.Button();
            this.syntymäaika = new System.Windows.Forms.DateTimePicker();
            this.nimitiedot.SuspendLayout();
            this.peli.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial Rounded MT Bold", 27.75F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(299, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(185, 43);
            this.label1.TabIndex = 0;
            this.label1.Text = "Ristinolla";
            // 
            // nimi
            // 
            this.nimi.AutoSize = true;
            this.nimi.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nimi.Location = new System.Drawing.Point(6, 16);
            this.nimi.Name = "nimi";
            this.nimi.Size = new System.Drawing.Size(179, 24);
            this.nimi.TabIndex = 1;
            this.nimi.Text = "Etu,- ja sukunimi";
            // 
            // saika
            // 
            this.saika.AutoSize = true;
            this.saika.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.saika.Location = new System.Drawing.Point(6, 51);
            this.saika.Name = "saika";
            this.saika.Size = new System.Drawing.Size(139, 24);
            this.saika.TabIndex = 2;
            this.saika.Text = "Syntymäaika";
            // 
            // nimitiedot
            // 
            this.nimitiedot.Controls.Add(this.syntymäaika);
            this.nimitiedot.Controls.Add(this.VSkone);
            this.nimitiedot.Controls.Add(this.Pelaaja2bt);
            this.nimitiedot.Controls.Add(this.Pelaaja1bt);
            this.nimitiedot.Controls.Add(this.Aloitanappi);
            this.nimitiedot.Controls.Add(this.nimitxt);
            this.nimitiedot.Controls.Add(this.nimi);
            this.nimitiedot.Controls.Add(this.saika);
            this.nimitiedot.Location = new System.Drawing.Point(178, 55);
            this.nimitiedot.Name = "nimitiedot";
            this.nimitiedot.Size = new System.Drawing.Size(454, 119);
            this.nimitiedot.TabIndex = 4;
            this.nimitiedot.TabStop = false;
            this.nimitiedot.Enter += new System.EventHandler(this.nimitiedot_Enter);
            // 
            // VSkone
            // 
            this.VSkone.AutoSize = true;
            this.VSkone.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.VSkone.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.VSkone.Location = new System.Drawing.Point(232, 89);
            this.VSkone.Name = "VSkone";
            this.VSkone.Size = new System.Drawing.Size(98, 23);
            this.VSkone.TabIndex = 6;
            this.VSkone.Text = "VS kone";
            this.VSkone.UseVisualStyleBackColor = true;
            this.VSkone.Visible = false;
            this.VSkone.CheckedChanged += new System.EventHandler(this.VSkone_CheckedChanged);
            // 
            // Pelaaja2bt
            // 
            this.Pelaaja2bt.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Pelaaja2bt.Font = new System.Drawing.Font("Arial Rounded MT Bold", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Pelaaja2bt.Location = new System.Drawing.Point(119, 84);
            this.Pelaaja2bt.Name = "Pelaaja2bt";
            this.Pelaaja2bt.Size = new System.Drawing.Size(107, 29);
            this.Pelaaja2bt.TabIndex = 9;
            this.Pelaaja2bt.Text = "Pelaaja 2";
            this.Pelaaja2bt.UseVisualStyleBackColor = true;
            this.Pelaaja2bt.Visible = false;
            this.Pelaaja2bt.Click += new System.EventHandler(this.Pelaaja2bt_Click);
            // 
            // Pelaaja1bt
            // 
            this.Pelaaja1bt.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Pelaaja1bt.Font = new System.Drawing.Font("Arial Rounded MT Bold", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Pelaaja1bt.Location = new System.Drawing.Point(10, 84);
            this.Pelaaja1bt.Name = "Pelaaja1bt";
            this.Pelaaja1bt.Size = new System.Drawing.Size(103, 29);
            this.Pelaaja1bt.TabIndex = 8;
            this.Pelaaja1bt.Text = "Pelaaja 1 ";
            this.Pelaaja1bt.UseVisualStyleBackColor = true;
            this.Pelaaja1bt.Click += new System.EventHandler(this.Pelaaja1bt_Click);
            // 
            // Aloitanappi
            // 
            this.Aloitanappi.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Aloitanappi.Font = new System.Drawing.Font("Arial Rounded MT Bold", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Aloitanappi.Location = new System.Drawing.Point(334, 84);
            this.Aloitanappi.Name = "Aloitanappi";
            this.Aloitanappi.Size = new System.Drawing.Size(107, 29);
            this.Aloitanappi.TabIndex = 7;
            this.Aloitanappi.Text = "Aloita";
            this.Aloitanappi.UseVisualStyleBackColor = true;
            this.Aloitanappi.Visible = false;
            this.Aloitanappi.Click += new System.EventHandler(this.button3_Click);
            // 
            // nimitxt
            // 
            this.nimitxt.BackColor = System.Drawing.Color.White;
            this.nimitxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.nimitxt.Location = new System.Drawing.Point(251, 19);
            this.nimitxt.Name = "nimitxt";
            this.nimitxt.Size = new System.Drawing.Size(190, 20);
            this.nimitxt.TabIndex = 3;
            this.nimitxt.TextChanged += new System.EventHandler(this.nimitxt_TextChanged);
            // 
            // peli
            // 
            this.peli.Controls.Add(this.uudestaan);
            this.peli.Controls.Add(this.label4);
            this.peli.Controls.Add(this.vuoroo);
            this.peli.Controls.Add(this.label3);
            this.peli.Controls.Add(this.label2);
            this.peli.Controls.Add(this.vuorox);
            this.peli.Controls.Add(this.button3);
            this.peli.Controls.Add(this.button9);
            this.peli.Controls.Add(this.button8);
            this.peli.Controls.Add(this.button2);
            this.peli.Controls.Add(this.button1);
            this.peli.Controls.Add(this.button7);
            this.peli.Controls.Add(this.button6);
            this.peli.Controls.Add(this.button4);
            this.peli.Controls.Add(this.button5);
            this.peli.Location = new System.Drawing.Point(202, 180);
            this.peli.Name = "peli";
            this.peli.Size = new System.Drawing.Size(430, 250);
            this.peli.TabIndex = 5;
            this.peli.TabStop = false;
            this.peli.Visible = false;
            this.peli.Enter += new System.EventHandler(this.peli_Enter);
            // 
            // uudestaan
            // 
            this.uudestaan.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.uudestaan.Font = new System.Drawing.Font("Arial Rounded MT Bold", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uudestaan.Location = new System.Drawing.Point(282, 142);
            this.uudestaan.Name = "uudestaan";
            this.uudestaan.Size = new System.Drawing.Size(94, 44);
            this.uudestaan.TabIndex = 9;
            this.uudestaan.Text = "Pelaa uudestaan";
            this.uudestaan.UseVisualStyleBackColor = true;
            this.uudestaan.Click += new System.EventHandler(this.uudestaan_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(339, 45);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(81, 18);
            this.label4.TabIndex = 7;
            this.label4.Text = "Pelaaja 2";
            // 
            // vuoroo
            // 
            this.vuoroo.AutoSize = true;
            this.vuoroo.Font = new System.Drawing.Font("Arial Rounded MT Bold", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.vuoroo.Location = new System.Drawing.Point(364, 73);
            this.vuoroo.Name = "vuoroo";
            this.vuoroo.Size = new System.Drawing.Size(31, 28);
            this.vuoroo.TabIndex = 7;
            this.vuoroo.Text = "O";
            this.vuoroo.Visible = false;
            this.vuoroo.Click += new System.EventHandler(this.vuoroo_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(252, 45);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(81, 18);
            this.label3.TabIndex = 6;
            this.label3.Text = "Pelaaja 1";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(310, 16);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(56, 18);
            this.label2.TabIndex = 6;
            this.label2.Text = "Vuoro";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // vuorox
            // 
            this.vuorox.AutoSize = true;
            this.vuorox.Font = new System.Drawing.Font("Arial Rounded MT Bold", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.vuorox.Location = new System.Drawing.Point(277, 73);
            this.vuorox.Name = "vuorox";
            this.vuorox.Size = new System.Drawing.Size(26, 28);
            this.vuorox.TabIndex = 6;
            this.vuorox.Text = "X";
            this.vuorox.Click += new System.EventHandler(this.vuorox_Click);
            // 
            // button3
            // 
            this.button3.Font = new System.Drawing.Font("Arial Rounded MT Bold", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.Location = new System.Drawing.Point(166, 177);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 66);
            this.button3.TabIndex = 8;
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click_1);
            // 
            // button9
            // 
            this.button9.Font = new System.Drawing.Font("Arial Rounded MT Bold", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button9.Location = new System.Drawing.Point(85, 178);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(75, 66);
            this.button9.TabIndex = 7;
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            this.button9.MouseClick += new System.Windows.Forms.MouseEventHandler(this.button10_MouseClick);
            // 
            // button8
            // 
            this.button8.Font = new System.Drawing.Font("Arial Rounded MT Bold", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button8.Location = new System.Drawing.Point(4, 177);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(75, 66);
            this.button8.TabIndex = 6;
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            this.button8.MouseClick += new System.Windows.Forms.MouseEventHandler(this.button10_MouseClick);
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Arial Rounded MT Bold", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(85, 34);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 66);
            this.button2.TabIndex = 1;
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Arial Rounded MT Bold", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(4, 34);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 66);
            this.button1.TabIndex = 0;
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            this.button1.MouseClick += new System.Windows.Forms.MouseEventHandler(this.button10_MouseClick);
            // 
            // button7
            // 
            this.button7.Font = new System.Drawing.Font("Arial Rounded MT Bold", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button7.Location = new System.Drawing.Point(4, 106);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(75, 66);
            this.button7.TabIndex = 5;
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            this.button7.MouseClick += new System.Windows.Forms.MouseEventHandler(this.button10_MouseClick);
            // 
            // button6
            // 
            this.button6.Font = new System.Drawing.Font("Arial Rounded MT Bold", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button6.Location = new System.Drawing.Point(85, 105);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(75, 66);
            this.button6.TabIndex = 4;
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            this.button6.MouseClick += new System.Windows.Forms.MouseEventHandler(this.button10_MouseClick);
            // 
            // button4
            // 
            this.button4.Font = new System.Drawing.Font("Arial Rounded MT Bold", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.Location = new System.Drawing.Point(166, 34);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(75, 66);
            this.button4.TabIndex = 2;
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            this.button4.MouseClick += new System.Windows.Forms.MouseEventHandler(this.button10_MouseClick);
            // 
            // button5
            // 
            this.button5.Font = new System.Drawing.Font("Arial Rounded MT Bold", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button5.Location = new System.Drawing.Point(166, 106);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(75, 66);
            this.button5.TabIndex = 3;
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            this.button5.MouseClick += new System.Windows.Forms.MouseEventHandler(this.button10_MouseClick);
            // 
            // Tilasto
            // 
            this.Tilasto.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Tilasto.Font = new System.Drawing.Font("Arial Rounded MT Bold", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Tilasto.Location = new System.Drawing.Point(676, 95);
            this.Tilasto.Name = "Tilasto";
            this.Tilasto.Size = new System.Drawing.Size(86, 35);
            this.Tilasto.TabIndex = 6;
            this.Tilasto.Text = "Tilasto";
            this.Tilasto.UseVisualStyleBackColor = true;
            this.Tilasto.Click += new System.EventHandler(this.Tilasto_Click);
            // 
            // takaisin
            // 
            this.takaisin.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.takaisin.Font = new System.Drawing.Font("Arial Rounded MT Bold", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.takaisin.Location = new System.Drawing.Point(676, 55);
            this.takaisin.Name = "takaisin";
            this.takaisin.Size = new System.Drawing.Size(86, 33);
            this.takaisin.TabIndex = 7;
            this.takaisin.Text = "Menu";
            this.takaisin.UseVisualStyleBackColor = true;
            this.takaisin.Click += new System.EventHandler(this.takaisin_Click);
            // 
            // syntymäaika
            // 
            this.syntymäaika.Location = new System.Drawing.Point(251, 54);
            this.syntymäaika.Name = "syntymäaika";
            this.syntymäaika.Size = new System.Drawing.Size(190, 20);
            this.syntymäaika.TabIndex = 10;
            this.syntymäaika.ValueChanged += new System.EventHandler(this.syntymäaika_ValueChanged);
            // 
            // Ristinolla
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkRed;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.takaisin);
            this.Controls.Add(this.Tilasto);
            this.Controls.Add(this.peli);
            this.Controls.Add(this.nimitiedot);
            this.Controls.Add(this.label1);
            this.Name = "Ristinolla";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Ristinolla";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.nimitiedot.ResumeLayout(false);
            this.nimitiedot.PerformLayout();
            this.peli.ResumeLayout(false);
            this.peli.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label nimi;
        private System.Windows.Forms.Label saika;
        private System.Windows.Forms.GroupBox nimitiedot;
        private System.Windows.Forms.TextBox nimitxt;
        private System.Windows.Forms.Button Aloitanappi;
        private System.Windows.Forms.GroupBox peli;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button Pelaaja2bt;
        private System.Windows.Forms.Button Pelaaja1bt;
        private System.Windows.Forms.Label vuoroo;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label vuorox;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.CheckBox VSkone;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.Button Tilasto;
        private System.Windows.Forms.Button uudestaan;
        private System.Windows.Forms.Button takaisin;
        private System.Windows.Forms.DateTimePicker syntymäaika;
    }
}

